

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.part1.Login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Dell
 */
public class Part1Test {
    Login validLogin ;
     Login invalidUsernameLogin;
    Login validPasswordLogin;
     Login invalidPasswordLogin;
    public Part1Test() {
        
        validLogin = new Login("kyl_1", "Ch&&sec@ke99!", "Anza", "M");
        invalidUsernameLogin = new Login("kyle!!!!!!!", "Ch&&sec@ke99!", "Anza", "M");
        validPasswordLogin = new Login("kyl_1", "Ch&&sec@ke99!", "Anza", "M");
        invalidPasswordLogin = new Login("kyl_1", "password", "Anza", "M");
    }
 
    @Test
    public void testCorrectUsernameFormat() {
        assertTrue(validLogin.checkUserName());
        assertEquals("Welcome Anza M, it is great to see you again.", 
                      validLogin.returnLoginStatus("kyl_1", "Ch&&sec@ke99!"));
    }

   
    @Test
    public void testIncorrectUsernameFormat() {
        assertFalse(invalidUsernameLogin.checkUserName());
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.",
                      invalidUsernameLogin.registerUser());
    }

   
    @Test
    public void testCorrectPasswordComplexity() {
        assertTrue(validPasswordLogin.checkPasswordComplexity());
       
    }


    @Test
    public void testIncorrectPasswordComplexity() {
        assertFalse(invalidPasswordLogin.checkPasswordComplexity());
     
    }

 
    @Test
    public void testLoginSuccess() {
        assertTrue(validLogin.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }


 
    @Test
    public void testLoginFailed() {
        assertFalse(validLogin.loginUser("kyl_1", "wrongpassword"));
    }
       @Test
    public void testUsernameCorrect() {
        assertTrue(validLogin.checkUserName());
    }


 
    @Test
    public void testUsernameIncorrect() {
        assertFalse(invalidUsernameLogin.checkUserName());
    }
    
         @Test
    public void testPasswordCorrect() {
        assertTrue(validPasswordLogin.checkPasswordComplexity());
    }


 
    @Test
    public void testPasswordIncorrect() {
        assertFalse(invalidPasswordLogin.checkPasswordComplexity());
    }
    
    
    
}
